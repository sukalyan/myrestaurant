<?php

$host="localhost";
$userid="root";
$password="colourfade";
$db="wang_resturant";
$con=mysql_connect($host,$userid,$password);
mysql_select_db($db,$con);
$linkval="http://50.56.237.229/wang/phpfiles/confirmation.php";
?>
